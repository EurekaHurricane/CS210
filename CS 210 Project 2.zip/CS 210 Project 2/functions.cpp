#include "functions.h"
// declare varriables
public;
float startingInvestment, monthlyDeposit, InterestRate;
float currentTotal, interestPaid, yearlyInterestPaid;
int months, years;

//Display Input that variables that will be required so user has info ready
cout << "*************************\n";
cout << "****** Data Input *******\n";
cout << "Initial Investment Amount : \n";
cout << "   Monthly Deposit: \n";
cout << "   Annual Interest: \n";
cout << "   Number of years: \n";
system("PAUSE");

//Prompt for and get user input
cout << "*************************\n";
cout << "****** Data Input *******\n";

cout << "Initial Investment Amount: $";
cin >> startingInvestment;

cout << "Monthly Deposit: $";
cin >> monthlyDeposit;

cout << "Annual Interest: %";
cin >> InterestRate;

cout << "Number of years: ";
cin >> years;
months = years * 12;

currentTotal = startingInvestment;

cout << "\nBalance and Interest Without Additional Monthly Deposits\n";
cout << "================================================================\n";
cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
cout << "----------------------------------------------------------------\n";


for (int i = 0; i < years; i++) {

	interestPaid = (currentTotal) * ((InterestRate / 100));
	currentTotal = currentTotal + interestPaid;
	cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << currentTotal << "\t\t\t$" << interestPaid << "\n";
}

currentTotal = startingInvestment;
cout << "\nBalance and Interest With Additional Monthly Deposits\n";
cout << "================================================================\n";
cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
cout << "----------------------------------------------------------------\n";


for (int i = 0; i < years; i++) {
	yearlyInterestPaid = 0;


	for (int j = 0; j < 12; j++) {

		interestPaid = (currentTotal + monthlyDeposit) * ((InterestRate / 100) / 12);
		yearlyInterestPaid = yearlyInterestPaid + interestPaid;
		currentTotal = currentTotal + monthlyDeposit + interestPaid;
	}

	cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << currentTotal << "\t\t\t$" << yearlyInterestPaid << "\n";
}