#include <iostream>
#include <iomanip>
using namespace std;

int main() {

// declare variables

	float startingInvestment, monthlyDeposit, InterestRate; 
	float currentTotal, interestPaid, yearlyInterestPaid;
	int months, years;

//Display Input variables that will be required so user has info ready
	cout << "*************************" << endl;
	cout << "***** Required Data *****" << endl;
	cout << "Initial Investment Amount: " << endl;
	cout << "Monthly Deposit: " << endl;
	cout << "Annual Interest: " << endl;
	cout << "Number of years: " << endl << endl;
	system("PAUSE");
	cout << endl;

//Prompt for and get user input

	cout << "*************************" << endl;
	cout << "****** Input Data *******" << endl;
	cout << "Initial Investment Amount: $";
	cin >> startingInvestment;
	cout << "Monthly Deposit: $";
	cin >> monthlyDeposit;
	cout << "Annual Interest: %";
	cin >> InterestRate;
	cout << "Number of years: ";
	cin >> years;
	months = years * 12;
	cout << endl;
	system("PAUSE");

//Header for Balance plus interest without deposits
	
	cout << endl;
	cout << "   Balance and Interest Without Additional Monthly Deposits" << endl;
	cout << "================================================================" << endl;
	cout << " Year      Year End Balance      Annual Interest Earned" << endl;
	cout << "----------------------------------------------------------------" << endl;

// loop to add interest without deposits for amount of years chosen

	currentTotal = startingInvestment;

	for (int i = 0; i < years; i++) {
		interestPaid = (currentTotal) * ((InterestRate / 100));
		currentTotal = currentTotal + interestPaid;
		cout << "  " << (i + 1) << "		$" << fixed << setprecision(2) << currentTotal << "			$" << interestPaid << endl;
	}

// Header for Balance and interest with additional deposits
	cout << endl << endl;
	cout << "     Balance and Interest With Additional Monthly Deposits" << endl;
	cout << "================================================================" << endl;
	cout << " Year      Year End Balance      Annual Interest Earned" << endl;
	cout << "----------------------------------------------------------------" << endl;

// loop to add annual interest for number of years chosen

	currentTotal = startingInvestment;

	for (int i = 0; i < years; i++) {
		yearlyInterestPaid = 0;

// loop to add deposits for total months of amount of years chosen

		for (int j = 0; j < 12; j++) {
			interestPaid = (currentTotal + monthlyDeposit) * ((InterestRate / 100) / 12);
			yearlyInterestPaid = yearlyInterestPaid + interestPaid;
			currentTotal = currentTotal + monthlyDeposit + interestPaid;
		}

		cout << "  " << (i + 1) << "		$" << fixed << setprecision(2) << currentTotal << "			$" << yearlyInterestPaid << endl;
	}
	return 0;
}